﻿namespace _4.Distance_Between_Points
{
    public class PointsAdd
    {
        public double PointX { get; set; }

        public double PointY { get; set; }
    }
}
